import React from 'react';
import Router from './ReactProyect/Routers';
import { BrowserRouter } from 'react-router-dom';


function App(){
    return(       
        <Router />
    )
}

export default App;