Crear la BD y hacer las migraciones, (en la carpeta /databases hay una copia de la BD, tambien la puede sencillamente exportar y ya ) 
ejecutar 
composer install
npm install
php artisan serve,  npm run watch-poll